<?php
  include_once "includes/connect.php";
  session_start();
  if($_SESSION['studentid'] <= 0){
    echo "<script type='text/javascript'> document.location ='login.php'; </script>";
  }
  $poll = "None";
  $items = mysqli_query($connect,"select * from product");
  $id = $_SESSION['studentid'];
  $stmtname = "select name from tbl_client where id='$id'";
  $nameres = mysqli_query($connect,$stmtname);
  
  $row=mysqli_fetch_array($nameres);
  $name=$row['name'];
  $date = date("d-m-Y");
  if(isset($_POST['submit']))
        {

            $poll = $_POST['poll'];
            $stmt = "insert into votes(foodname,studentname,date) values('$poll','$name','$date')";
            mysqli_query($connect,$stmt);
            echo '<script>alert("You Voted For '.$poll.'")</script>';

        }

?>
<!DOCTYPE html>
<html>
<head>
<title>Student Mess</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="css\style.css">
<style>
body {font-family: "Times New Roman", Georgia, Serif;}
h1, h2, h3, h4, h5, h6 {
  font-family: "Playfair Display";
  letter-spacing: 5px;
}
</style>
</head>
<body>

<!-- Navbar (sit on top) -->
<?php
  include_once "includes/navbar.php";
?>


<div class="wrapper">
  <header>Select Food</header>
  
  <div class="poll-area">
    <form method="post" action="">
      <select id="mySelect" name="poll">
    <?php
    
      while($row=mysqli_fetch_array($items))
      { 
    ?>
          
            <option><?php echo $row['product_name'];?></option>
          

    <?php
      }
    ?>
    </select>
    <br><br>
    <div class="d-grid">
        <button class="btn btn-primary" type="submit" name="submit">Vote</button>
    </div>
    </form>
  </div>
</div>



<!-- Footer -->
<footer class="w3-center w3-light-grey w3-padding-32">
  
</footer>

</body>
<script>
  const options = document.querySelectorAll("label");
for (let i = 0; i < options.length; i++) {
  options[i].addEventListener("click", ()=>{
    for (let j = 0; j < options.length; j++) {
      if(options[j].classList.contains("selected")){
        options[j].classList.remove("selected");
      }
    }

    options[i].classList.add("selected");
    for (let k = 0; k < options.length; k++) {
      options[k].classList.add("selectall");
    }

    let forVal = options[i].getAttribute("for");
    let selectInput = document.querySelector("#"+forVal);
    let getAtt = selectInput.getAttribute("type");
    if(getAtt == "checkbox"){
      selectInput.setAttribute("type", "radio");
    }else if(selectInput.checked == true){
      options[i].classList.remove("selected");
      selectInput.setAttribute("type", "checkbox");
    }

    let array = [];
    for (let l = 0; l < options.length; l++) {
      if(options[l].classList.contains("selected")){
        array.push(l);
      }
    }
    if(array.length == 0){
      for (let m = 0; m < options.length; m++) {
        options[m].removeAttribute("class");
      }
    }
  });
}
</script>
</html>