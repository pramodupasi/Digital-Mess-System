<!DOCTYPE html>
<html>
<head>
    <?php
        $msg = "";
        include_once "includes/connect.php";
        session_start();
        if(isset($_POST['submit']))
        {
            echo "HI";
            $mob = $_POST['mob'];
            $id = $_POST['key'];

            $stmt = "select * from tbl_client where mob_no='$mob' and id='$id' ";
            $query = mysqli_query($connect,$stmt);
            if(mysqli_fetch_array($query)>1){
                $_SESSION['studentid'] = $id;
                $msg = "Login Success";
                echo "<script type='text/javascript'> document.location ='vote.php'; </script>";
            }
            else{
                $msg = "Wrong Key or Number";
            }
        }
      
    ?>
<title>Student Mess</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<style>
body {font-family: "Times New Roman", Georgia, Serif;}
h1, h2, h3, h4, h5, h6 {
  font-family: "Playfair Display";
  letter-spacing: 5px;
}
</style>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa"
        crossorigin="anonymous"></script>
</head>


<body>

<?php
  include_once "includes/navbar.php";
?>

    <div class="vh-100 d-flex justify-content-center align-items-center ">
        <div class="col-md-5 p-5 shadow-sm border rounded-5 border-primary bg-white">
            <h2 class="text-center mb-4 text-primary">Login Form</h2>
            <?php
                echo $msg;
            ?>
            <form action="" method="post">
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Mobile Number</label>
                    <input type="number" name="mob" class="form-control border border-primary" id="exampleInputEmail1" aria-describedby="emailHelp">
                </div>
                <div class="mb-3">
                    <label for="exampleInputPassword1" class="form-label">Pass Key</label>
                    <input type="password" name="key" class="form-control border border-primary" id="exampleInputPassword1">
                </div>
                
                <div class="d-grid">
                    <button class="btn btn-primary" type="submit" name="submit">Login</button>
                </div>
            </form>
            
        </div>
    </div>
</body>

</html>

