<div class="w3-top">
  <div class="w3-bar w3-white w3-padding w3-card" style="letter-spacing:4px;">
    <a href="#home" class="w3-bar-item w3-button">Mess | Eat, Study, Sleep</a>
    <!-- Right-sided navbar links. Hide them on small screens -->
    <div class="w3-right w3-hide-small">
      <a href="index.php#about" class="w3-bar-item w3-button">About</a>
      <a href="index.php#menu" class="w3-bar-item w3-button">Menu</a>
      <a href="vote.php" class="w3-bar-item w3-button">Vote</a>
      <a href="index.php#contact" class="w3-bar-item w3-button">Contact</a>
      
      <?php
      
        if($_SESSION['studentid'] <= 0){
            ?>
        <a href="login.php" class="w3-bar-item w3-button">Student Login</a>
       <?php  }
      ?>
      <?php
        if($_SESSION['studentid'] >= 0){
            ?>
        <a href="logout.php" class="w3-bar-item w3-button">Logout</a>
       <?php  }
      ?>
      
      <a href="../admin/" class="w3-bar-item w3-button">Admin Login</a>
    </div>
  </div>
</div>