<?php
header("Location: student/index.php");
?>