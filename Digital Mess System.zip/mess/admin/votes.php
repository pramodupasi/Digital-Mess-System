<?php include('./constant/layout/head.php');?>
<?php include('./constant/layout/header.php');?>

<?php include('./constant/layout/sidebar.php');?>   
<?php include('./constant/connect');
$date = date("d-m-Y");
$sql = "SELECT * FROM `votes` where date='$date'";
$result = $connect->query($sql);
//echo $sql;exit;

?>
       <div class="page-wrapper">
            
            
            
            <div class="container-fluid">
                
                
                
                
                 <div class="card">
                            <div class="card-body">
                              
                           
                         
                                <div class="table-responsive m-t-40">
                                    <table id="myTable" class="table table-bordered table-striped">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Student Name</th>
                                                <th>Food Name</th>
                                                <th>Date</th>
                                            </tr>
                                       </thead>
                                       <tbody>
                                        <?php
foreach ($result as $row) {
    $no+=1;
    ?>
                                        <tr>
                                            <td><?php echo$no; ?></td>
                                            <td><?php echo $row['studentname'] ?></td>
                                            <td><?php echo $row['foodname'] ?></td>
                                            <td><?php echo $row['date'] ?></td>
                                        </tr>
                                      <?php }?>
                                    </tbody>
                                   
                               </table>
                                </div>
                            </div>
                        </div>

<?php include('./constant/layout/footer.php');?>


